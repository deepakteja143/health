package com.project.staragile;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicureRepository extends JpaRepository<Doctor,String>{

}
